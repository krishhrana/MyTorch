from collections import Counter

import numpy as np

class GreedySearchDecoder(object):

    def __init__(self, symbol_set):
        """
        
        Initialize instance variables

        Argument(s)
        -----------

        symbol_set [list[str]]:
            all the symbols (the vocabulary without blank)

        """

        self.symbol_set = symbol_set


    def decode(self, y_probs):
        """

        Perform greedy search decoding

        Input
        -----

        y_probs [np.array, dim=(len(symbols) + 1, seq_length, batch_size)]
            batch size for part 1 will remain 1, but if you plan to use your
            implementation for part 2 you need to incorporate batch_size

        Returns
        -------

        decoded_path [str]:
            compressed symbol sequence i.e. without blanks or repeated symbols

        path_prob [float]:
            forward probability of the greedy path

        """

        decoded_path = []
        blank = 0
        path_prob = 1

        # TODO:
        # 1. Iterate over sequence length - len(y_probs[0])
        # 2. Iterate over symbol probabilities
        # 3. update path probability, by multiplying with the current max probability
        # 4. Select most probable symbol and append to decoded_path
        # 5. Compress sequence (Inside or outside the loop)


        symbol_length, seq_len, batch_size = y_probs.shape


        for t in range(seq_len):
            probs_t = y_probs[:, t, :]
            max_idx = np.argmax(probs_t)
            max_prob = probs_t[max_idx]
            if max_idx == 0:
                decoded_path.append('BLANK')
            else:
                decoded_path.append(self.symbol_set[max_idx - 1])
            path_prob *= max_prob

        compressed_path = [decoded_path[0]]
        for i in range(1, len(decoded_path)):
            if decoded_path[i] != decoded_path[i - 1]:
                compressed_path.append(decoded_path[i])

        compressed_path = np.array(compressed_path)
        decoded_path = "".join(compressed_path[compressed_path != 'BLANK'])


        return decoded_path, path_prob


class BeamSearchDecoder(object):

    def __init__(self, symbol_set, beam_width):
        """

        Initialize instance variables

        Argument(s)
        -----------

        symbol_set [list[str]]:
            all the symbols (the vocabulary without blank)

        beam_width [int]:
            beam width for selecting top-k hypotheses for expansion

        """

        self.symbol_set = symbol_set
        self.beam_width = beam_width

    def decode(self, y_probs):
        """
        
        Perform beam search decoding

        Input
        -----

        y_probs [np.array, dim=(len(symbols) + 1, seq_length, batch_size)]
			batch size for part 1 will remain 1, but if you plan to use your
			implementation for part 2 you need to incorporate batch_size

        Returns
        -------
        
        forward_path [str]:
            the symbol sequence with the best path score (forward probability)

        merged_path_scores [dict]:
            all the final merged paths with their scores

        """

        T = y_probs.shape[1]
        PathScore = {}  # dict of scores for paths ending with symbols
        BlankPathScore = {}  # dict of scores for paths ending with blanks
        num_symbols, seq_len, batch_size = y_probs.shape

        # First time instant: initialize paths with each of the symbols, including blank, using score at t=1
        NewPathsWithTerminalBlank, NewPathsWithTerminalSymbol, NewBlankPathScore, NewPathScore = self.InitializePaths(
            self.symbol_set, y_probs[:, 0, :])

        # Subsequent time steps
        for t in range(1, seq_len):
            PathsWithTerminalBlank, PathsWithTerminalSymbol, BlankPathScore, PathScore = self.Prune(
                NewPathsWithTerminalBlank,
                NewPathsWithTerminalSymbol,
                NewBlankPathScore, NewPathScore,
                self.beam_width)

            NewPathsWithTerminalBlank, NewBlankPathScore = self.ExtendWithBlank(PathsWithTerminalBlank,
                                                                           PathsWithTerminalSymbol, y_probs[:, t, :],
                                                                           BlankPathScore, PathScore)

            # Next extend paths by a symbol
            NewPathsWithTerminalSymbol, NewPathScore = self.ExtendWithSymbol(PathsWithTerminalBlank, PathsWithTerminalSymbol,
                                                                        self.symbol_set, y_probs[:, t, :], BlankPathScore,
                                                                        PathScore)

        # Merge identical paths differing only by the final blank
        MergedPaths, FinalPathScore = self.MergeIdenticalPaths(NewPathsWithTerminalBlank, NewPathsWithTerminalSymbol,
                                                          NewBlankPathScore, NewPathScore)

        # Pick the best path
        print(FinalPathScore)
        bestPath = max(FinalPathScore, key=FinalPathScore.get)  # Find the path with the best score

        return bestPath, FinalPathScore

    def InitializePaths(self, SymbolSets, y):
        InitialBlankPathScore, InitialPathScore = {}, {}
        # First push the blank into a path-ending-with-blank stack. No symbol has been invoked yet
        path = ""
        InitialBlankPathScore[path] = y[0]  # Score of blank at t=1
        InitialPathsWithFinalBlank = set()
        InitialPathsWithFinalBlank.add(path)

        # Push rest of the symbols into a path-ending-with-symbol set, without the blank
        InitialPathsWithFinalSymbol = set()
        for i in range(len(SymbolSets)):
            path = SymbolSets[i]
            InitialPathScore[path] = y[i + 1]
            InitialPathsWithFinalSymbol.add(path)  # set addition
        return InitialPathsWithFinalBlank, InitialPathsWithFinalSymbol, InitialBlankPathScore, InitialPathScore

    def ExtendWithBlank(self, PathsWithTerminalBlank, PathsWithTerminalSymbol, y, BlankPathScore, PathScore):
        UpdatedPathsWithTerminalBlank = set()
        UpdatedBlankPathScore = {}

        # First work on paths with terminal blanks, horizontal transitions
        for path in PathsWithTerminalBlank:
            # Repeating a blank does not change the symbol sequence
            UpdatedPathsWithTerminalBlank.add(path)
            UpdatedBlankPathScore[path] = BlankPathScore[path] * y[0]
        # Then extend paths with terminal symbols by blanks
        for path in PathsWithTerminalSymbol:
            # If there is already an equivalent string in UpdatedPathsWithTerminalBlank
            # simply add the score. If not create a new entry
            if path in UpdatedPathsWithTerminalBlank:
                UpdatedBlankPathScore[path] += PathScore[path] * y[0]
            else:
                UpdatedPathsWithTerminalBlank.add(path)
                UpdatedBlankPathScore[path] = PathScore[path] * y[0]
        return UpdatedPathsWithTerminalBlank, UpdatedBlankPathScore

    def ExtendWithSymbol(self, PathsWithTerminalBlank, PathsWithTerminalSymbol, SymbolSet, y, BlankPathScore, PathScore):
        UpdatedPathsWithTerminalSymbol = set()
        UpdatedPathScore = {}

        # First extend the paths terminating in blanks. This will always create a new sequence
        for path in PathsWithTerminalBlank:
            for i in range(len(SymbolSet)):  # Symbolset does not include blanks
                newpath = path + SymbolSet[i]
                UpdatedPathsWithTerminalSymbol.add(newpath)
                UpdatedPathScore[newpath] = BlankPathScore[path] * y[i + 1]

        # Next work on paths with terminal symbols
        for path in PathsWithTerminalSymbol:
            for i in range(len(SymbolSet)):  # Symbolset does not include blanks
                # Extend the path with every symbol other than blank
                newpath = path if (SymbolSet[i] == path[-1]) else path + SymbolSet[i]  # horizontal
                if newpath in UpdatedPathsWithTerminalSymbol:  # Already in list, merge paths
                    UpdatedPathScore[newpath] += PathScore[path] * y[i + 1]
                else:  # Create new path
                    UpdatedPathsWithTerminalSymbol.add(newpath)
                    UpdatedPathScore[newpath] = PathScore[path] * y[i + 1]
        return UpdatedPathsWithTerminalSymbol, UpdatedPathScore

    def Prune(self, PathsWithTerminalBlank, PathsWithTerminalSymbol, BlankPathScore, PathScore, BeamWidth):
        PrunedBlankPathScore, PrunedPathScore = {}, {}
        PrunedPathsWithTerminalBlank, PrunedPathsWithTerminalSymbol = set(), set()
        scorelist = []
        # First gather all the relevant scores
        for p in PathsWithTerminalBlank:
            scorelist.append(BlankPathScore[p])
        for p in PathsWithTerminalSymbol:
            scorelist.append(PathScore[p])

        # Sort and find cutoff score that retains exactly BeamWidth paths
        scorelist.sort(reverse=True)
        cutoff = scorelist[BeamWidth] if (BeamWidth < len(scorelist)) else scorelist[-1]

        for p in PathsWithTerminalBlank:
            if BlankPathScore[p] > cutoff:
                PrunedPathsWithTerminalBlank.add(p)
                PrunedBlankPathScore[p] = BlankPathScore[p]

        for p in PathsWithTerminalSymbol:
            if PathScore[p] > cutoff:
                PrunedPathsWithTerminalSymbol.add(p)
                PrunedPathScore[p] = PathScore[p]
        return PrunedPathsWithTerminalBlank, PrunedPathsWithTerminalSymbol, PrunedBlankPathScore, PrunedPathScore

    def MergeIdenticalPaths(self, PathsWithTerminalBlank, PathsWithTerminalSymbol, BlankPathScore, PathScore):
        # All paths with terminal symbosl will remain
        MergedPaths = PathsWithTerminalSymbol
        FinalPathScore = PathScore

        # Paths with terminal blanks will contribute scores to existing identical paths from
        # PathsWithTerminalSymbol if present, or be included in the final set, otherwise
        for p in PathsWithTerminalBlank:
            if p in MergedPaths:
                FinalPathScore[p] += BlankPathScore[p]
            else:
                MergedPaths.add(p)
                FinalPathScore[p] = BlankPathScore[p]
        return MergedPaths, FinalPathScore

    '''def process(self, paths, y_probs, t):
        if t > self.T:
            return paths

        paths = self.create_paths(paths)
        path_probs = self.





    def create_paths(self, paths):
        a = []
        for p in paths:
            for s in self.symbol_set:
                a.append(p + s)
        return a

    def get_path_probs(self, paths, path_prob, symbol_probs): #(array, counter, counter)
        c = Counter()
        for p in paths:
            prev_path = p[:-1]
            prev_path_prob = path_prob[prev_path]
            new_path_prob = prev_path_prob * symbol_probs[p[-1]]
            c[p] = new_path_prob
        return c

    def compress_path(self, c):
        decoded_path = list(c.keys())
        probs = list(c.values())

        compressed_rep = Counter()

        for d, p in zip(decoded_path, probs):
            compressed_path = [d[0]]
            for i in range(1, len(d)):
                if d[i] != d[i - 1]:
                    compressed_path.append(d[i])

            compressed_path = np.array(compressed_path)

            compressed_string = "".join(compressed_path[compressed_path != "BLANK"])
            compressed_rep[compressed_string] += p


    def retain_top_k(self, c, top_k):
        top_k_counter = Counter()
        top_k_paths = c.most_common(top_k)
        for i in top_k_paths:
            top_k_counter[i[0]] = i[1]

        return top_k_counter'''


