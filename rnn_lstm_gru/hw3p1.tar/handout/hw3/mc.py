def question_1():
    # return ""
    return 'b'


def question_2():
    # return ""
    return 'b'


def question_3():
    # return ""
    return 'b'


def question_4():
    # return ""
    return 'a'
